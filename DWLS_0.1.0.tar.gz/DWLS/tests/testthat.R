library(testthat)
library(DWLS)

test_check("DWLS")
