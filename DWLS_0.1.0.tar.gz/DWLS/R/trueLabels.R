#' Single cell data labels
#'
#' The "true labels" for the example single-cell labels from clustering.
#'
#' @format Data
#' @source \url{https://github.com/dtsoucas/DWLS/tree/master/ISC/data}

"trueLabels"
