#' Signature matrix
#'
#' This is an example of the output form buildSignatureMatrixUsingSeurat
#' function. A similar output is created using buildSignatureMatrixMAST.
#'
#'
#' @format Data
"Sig"
